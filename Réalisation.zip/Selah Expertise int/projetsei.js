// Script d'interaction de base
document.addEventListener("DOMContentLoaded", () => {
    // Mettre en surbrillance le lien actif
    const links = document.querySelectorAll("menu");
    const sections = document.querySelectorAll("section");

    function onScroll() {
        let scrollY = window.scrollY;
        sections.forEach((section, index) => {
            if (scrollY >= section.offsetTop - 60) {
                links.forEach(link => link.classList.remove("active"));
                if (links[index]) links[index].classList.add("active");
            }
        });
    }

    window.addEventListener("scroll", onScroll);
});
let clock = document.getElementById("clock");
 <script>
            function afficherDateHeure() {
                const maintenant = new Date();
                const options = { year: 'numeric', month: 'long', day: 'numeric', hour: '2-digit', minute: '2-digit', second: '2-digit' };
                const heures = String(maintenant.getHours()).padStart(2, '0');
                const minutes = String(maintenant.getMinutes()).padStart(2, '0');
                const secondes = String(maintenant.getSeconds()).padStart(2, '0');
                const heureFormatee = `${heures}:${minutes}:${secondes}`;
                document.getElementById("clock").value = heureFormatee;
                setTimeout(afficherDateHeure, 1000);
                }
    afficherDateHeure();
    </script>

let mission = "Notre mission est d'appuyer chaque Organisation à explorer et optimiser les potentielles opportunités pour des solutions holistiques et durables.";
console.log(mission);